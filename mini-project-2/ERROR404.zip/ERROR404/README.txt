 --- Algorithm folder includes analysis of the data set used  for understanding of the pictures provided for training and validation    of main model.

---- Overall trained model  file contains the overall  model state details generated using Problem1_Task-2 notebook.

----Pretrained model file contains the model state details generated using Problem1_Task-1 notebook.

---ERROR404.PDF file contains final report of the work along with the You-tube link for the Solution for Task 2


